# ngt.github.io
Nevergiveup Thoughts page
